#include <stdio.h>

#define	WINCHESTER	"/dev/rw0z"
#define	FLOPPY		"/dev/rf0"
#define BUFBLOCKS	16
#define FLOPS		((BLOCKS + 1231) / 1232) /* No. of floppies needed */
#define TRACKS		((BLOCKS + BUFBLOCKS - 1) / BUFBLOCKS)
#define	MSG1		"Please insert the floppy disk numbered ......... %d\n"
#define	MSG2		"Hit the key marked RETURN to continue .......... "
#define	MSG3		"Please remove the floppy disk numbered ......... %d\n"

static char	Sccs_id[] = "@(#) f2w.c 1.6@(#)";

char	buffer[BUFBLOCKS*512];	/* Size of so-called track.		*/
char	dummy[512];		/* Dummy buffer for RETURN answer.	*/
int	fdisk;			/* Current floppy disk number.		*/
int	ftrack;			/* Current floppy track number.		*/
int	wtrack;			/* Current Winchester track number.	*/
int	strack;			/* Starting Winchester track number.	*/
int	nread;			/* Number of characters read.		*/
int	status;			/* System call returned status.		*/
int	wfile;			/* Winchester file number.		*/
int	ffile;			/* Floppy file number.			*/
int	rwtrack;		/* Restart wtrack.			*/
int	restart;		/* Restart in progress.			*/
int	skipfloppy;		/* Number of floppys to skip.		*/
int	i;			/* 					*/


fmtwinchester(name)
	char	*name;
	{
	char	buffer[132];

	printf("\nDo you want the Winchester disk (%s) formatted first? ",name);
	fflush(stdout);
	eatreturn();
	if (dummy[0] != 'y'  &&  dummy[0] != 'Y')  return;
	sprintf(buffer,"diskformat %s",name);
	system(buffer);
	}
eatreturn()
	{
	int	pid;

	pid = fork();
	if (pid)
		{
		gets(dummy);
		kill(pid,9);
		}
	else
		{
		while(1)
			{
			sleep(1);
			write(1,"\007",1);
			}
		}
	}

main(argc,argv)
	int	argc;
	char   *argv[];
	{
	char   *winchester;

	printf("\033[2J\033[H");
	printf("\033[7m");
	      /*........................................*/
	printf(" Callan Data Systems UNISTAR UNIX \n");
	printf("Floppy to winchester restore program - %d MB version.\n\n", MB);
	printf("\033[m");
	printf("This backup program is for use only with %dMB systems.\n",
	  MB);
	printf("Use with other disks will cause data to be");
	printf(" \033[1mLOST\033[m or \033[1mDESTROYED\033[m.\n\n");
	skipfloppys = 0;
	fdisk = 0;
	strack = 0;
	if (argc > 1)
		{
		if (strcmp(argv[1],"-skip") == 0)
			{
			skipfloppys = atoi(argv[2]);
			if (skipfloppys < 1  ||  skipfloppys > FLOPS - 1)
				{
				printf("You can only skip 1 to %d", FLOPS);
				printf(" floppys, not  %d\n",skipfloppys);
				return(7);
				}
			strack = skipfloppys * 77;
			printf("Skipping %d floppys, starting track = %d\n",
				skipfloppys,strack);
			fdisk = skipfloppys;
			if (argc > 2) winchester = argv[2];
			else winchester = WINCHESTER;
			}
		else
			winchester = argv[1];
		}
	else
		winchester = WINCHESTER;
	fmtwinchester(winchester);
	restart = 0;
	ftrack = 77;
	wfile = open(WINCHESTER,1);
	if (wfile == -1)
		{
		perror("Can't open the Winchester raw disk file");
		return(1);
		}
	ffile = open(FLOPPY,0);
	if (ffile == -1)
		{
		perror("Can't open the floppy raw disk file");
		return(2);
		}
	for (rwtrack = strack, wtrack = strack;
	  wtrack < TRACKS;
	  wtrack++, ftrack++)
		{
		if (ftrack > 76)
			{
			status = lseek(ffile,0,0);
			if (status == -1)
				{
				perror("Bad lseek on floppy file");
				return(6);
				}
			putchar('\n');
			if (fdisk && !restart)
				{
				printf(MSG3,fdisk);
				}
			if (restart)
				{
				printf("Please remove floppy %d.\n",fdisk+1);
				restart = 0;
				}
			fdisk++;
			printf(MSG1,fdisk);
			printf(MSG2);
			fflush(stdout);
			eatreturn();
			printf("\n<");
			for (i = 0;  i < 77;  i++)
				{
				putchar('-');
				}
			putchar('>');
			fflush(stdout);
			ftrack = 0;
			sleep(7);	/* Wait for floppy to spin up ... */
			rwtrack = wtrack;
			}
		nread = read(ffile,buffer,sizeof(buffer));
		if (nread == -1)
			{
			perror("Bad read on the floppy raw disk file");
			printf("Now restarting the read for floppy %.\n",fdisk);
			wtrack = rwtrack - 1;
			ftrack = 77;
			fdisk--;
			restart = 1;
			continue;
			}
		status = lseek(wfile,wtrack * sizeof(buffer),0);
		if (status == -1)
			{
			perror("Bad lseek on Winchester file decriptor");
			return(5);
			}
		status = write(wfile,buffer,nread);
		if (status == -1)
			{
			perror("Bad write on the Winchester raw disk file");
			return(3);
			}
		printf("\010\010> \010");
		fflush(stdout);
		}
	printf("\n\n*****  ALL DONE.  HIT THE RESET SWITCH.  *****\n\n");
	fflush(stdout);
	eatreturn();
	}
