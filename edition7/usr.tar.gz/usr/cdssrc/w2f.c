#include <stdio.h>

#define	WINCHESTER	"/dev/rw0z"
#define	FLOPPY		"/dev/rf0"
#define BUFBLOCKS	16
#define FLOPS		((BLOCKS + 1231) / 1232) /* No. of floppies needed */
#define TRACKS		((BLOCKS + BUFBLOCKS - 1) / BUFBLOCKS)
#define	MSG1		"Please insert the floppy disk numbered ......... %d\n"
#define	MSG2		"Hit the key marked RETURN to continue .......... "
#define	MSG3		"Please remove the floppy disk numbered ......... %d\n"

static char	Sccs_id[] = "@(#) w2f.c 1.6@(#)";

char	buffer[BUFBLOCKS*512];	/* Size of so-called track.		*/
char	dummy[512];		/* Dummy buffer for RETURN answer.	*/
int	fdisk;			/* Current floppy disk number.		*/
int	ftrack;			/* Current floppy track number.		*/
int	wtrack;			/* Current Winchester track number.	*/
int	strack;			/* Starting track number.		*/
int	nread;			/* Number of bytes read from disk.	*/
int	status;			/* System call returned status.		*/
int	wfile;			/* Winchester file number.		*/
int	ffile;			/* Floppy file number.			*/
int	skipfloppy;		/* Number of floppys to skip.		*/
int	i;			/* 					*/


fmtfloppys()
	{
	printf("The Winchester to floppy backup program will require a total\n");
	printf("of %d floppys.  Each floppy must be formatted.  ", FLOPS);
	printf("For your ease\n");
	printf("of use, this program will now loop and format floppys for you.\n");
	printf("\nIf your floppys are already formatted, answer `no' to the\n");
	printf("following question.\n");
	while(1)
		{
		printf("\nDo you want to format a(nother) floppy? ");
		fflush(stdout);
		eatreturn();
		if (dummy[0] != 'y'  &&  dummy[0] != 'Y') break;
		sleep(2);
		printf("\nO.K., please insert the floppy to be formatted.\n");
		printf("Hit RETURN when ready to format .... ");
		fflush(stdout);
		eatreturn();
		sleep(7);
		system("diskformat /dev/rf0");
		printf("\nPlease remove the floppy. It is now formatted.\n");
		}
	}

eatreturn()
	{
	int	pid;

	pid = fork();
	if (pid)
		{
		gets(dummy);
		kill(pid,9);
		}
	else
		{
		while(1)
			{
			sleep(1);
			write(1,"\007",1);
			}
		}
	}

main(argc,argv)
	int	argc;
	char   *argv[];
	{

	printf("\033[2J\033[H");
	printf("\033[7m");
	      /*........................................*/
	printf(" Callan Data Systems UNISTAR UNIX \n");
	printf("Winchester to floppy backup program - %d MB version.\n\n", MB);
	printf("\033[m");
	printf("This backup program is for use only with %dMB systems.\n",
	  MB);
	printf("Use with other disks will cause data to be");
	printf(" \033[1mLOST\033[m or \033[1mDESTROYED\033[m.\n\n");
	fmtfloppys();
	skipfloppys = 0;
	strack = 0;
	fdisk = 0;
	if (argc > 1)
		{
		if (strcmp(argv[1],"-skip") == 0)
			{
			skipfloppys = atoi(argv[2]);
			if (skipfloppys < 1  ||  skipfloppys > FLOPS - 1)
				{
				printf("You can only skip 1 to %d", FLOPS);
				printf(" floppys, not  %d\n",skipfloppys);
				return(7);
				}
			strack = skipfloppys * 77;
			printf("Skipping %d floppys, starting track = %d\n",
				skipfloppys,strack);
			fdisk = skipfloppys;
			}
		}
	ftrack = 77;
	wfile = open(WINCHESTER,0);
	if (wfile == -1)
		{
		perror("Can't open the Winchester raw disk file");
		return(1);
		}
	ffile = open(FLOPPY,1);
	if (ffile == -1)
		{
		perror("Can't open the floppy raw disk file");
		return(2);
		}
	for (wtrack = strack;
	  wtrack < TRACKS;
	  wtrack++, ftrack++)
		{
		status = lseek(wfile,wtrack * sizeof(buffer),0);
		if (status == -1)
			{
			perror("Bad lseek on Winchester file decriptor");
			return(5);
			}
		nread = read(wfile,buffer,sizeof(buffer));
		if (nread == -1)
			{
			perror("Bad read on the Winchester raw disk file");
			return(3);
			}
		if (ftrack > 76)
			{
			status = lseek(ffile,0,0);
			if (status == -1)
				{
				perror("Bad lseek on floppy file");
				return(6);
				}
			putchar('\n');
			if (fdisk)
				{
				printf(MSG3,fdisk);
				}
			fdisk++;
			printf(MSG1,fdisk);
			printf(MSG2);
			fflush(stdout);
			eatreturn();
			printf("\n<");
			for (i = 0;  i < 77;  i++)
				{
				putchar('-');
				}
			putchar('>');
			fflush(stdout);
			ftrack = 0;
			sleep(7);	/* Wait for floppy to spin up ... */
			}
		status = write(ffile,buffer,nread);
		if (status == -1)
			{
			perror("Bad write on the floppy raw disk file");
			return(4);
			}
		printf("\010\010> \010");
		fflush(stdout);
		}
	}
