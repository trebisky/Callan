/*
 * Simple terminal emulation
 */
#include <stdio.h>
#include <signal.h>
#include <sgtty.h>

char	*speed	= "4800";	/* default line speed */
char	*port	= "/dev/lp";	/* just for the Callan system */
char	*cfile	= NULL;		/* filename for capture */
FILE	*cfp = NULL;		/* fileptr for capture file */
int	son = 0;		/* 0 means no son yet */
int	pd = 0;			/* 0 means not open yet */
struct sgttyb	optty, nptty;
struct sgttyb	outty, nutty;

/*
 * sigsnag - catch a signal and terminate gracefully
 */
sigsnag()
{
	bailout(2);
}

main (argc,argv)
char	**argv;
{
	char	*p;
	int	baud;
	register t;

	--argc;
	++argv;
	while ( argc ) {
		p = *argv++;
		if ( argc < 2 )
			break;
		if ( *p == '-' && *(p+1) == 's' )
			speed = *argv++;
		if ( *p == '-' && *(p+1) == 'c' )
			cfile = *argv++;
		argc -= 2;
	}

	signal ( SIGHUP, sigsnag );
	signal ( SIGINT, sigsnag );

	switch ( atoi(speed) ) {
	case 300:
		baud = B300;
		break;
	case 1200:
		baud = B1200;
		break;
	case 2400:
		baud = B2400;
		break;
	case 4800:
		baud = B4800;
		break;
	case 9600:
		baud = B9600;
		break;
	default:
		error ( "invalid baud rate requested" );
		break;
	}

	if ( (t=open(port,2)) < 0 )
		error ( "Cannot open: ", port );
	pd = t;		/* keep pd zero till we are sure open is valid */

	ioctl ( pd, TIOCGETP, &optty );
	ioctl ( pd, TIOCGETP, &nptty );
	nptty.sg_ispeed = baud;
	nptty.sg_ospeed = baud;
	nptty.sg_flags = EVENP|ODDP|RAW|TANDEM;	/* ECHO off */
	ioctl ( pd, TIOCSETP, &nptty );
	printf ( "Connecting to %s at %s baud\n", port, speed );

	ioctl ( 0, TIOCGETP, &outty );
	ioctl ( 0, TIOCGETP, &nutty );
	nutty.sg_flags = EVENP|ODDP|RAW|TANDEM;	/* ECHO off */
	ioctl ( 0, TIOCSETP, &nutty );

	if ( (t=fork()) == 0 ) {
		if ( cfile ) {
			cfp = fopen ( cfile, "w" );
			if ( cfp == NULL )
				error ( "Cannot open capture file %s", cfile );
			printf( "Data capture to %s\n", cfile );
			clisten(cfp);
		} else
			listen();
	}
	if ( t < 0 )
		error ("Cannot fork");
	son = t;	/* keep son zero till fork is validated */
	for (;;) {
		char c;

		if ( read(0,&c,1) != 1 )
			continue;
		c &= 0177;
		if ( c == '~' )
			break;
		if ( write ( pd, &c, 1 ) != 1 )
			error ("Write error to port");
	}
	bailout(0);	/* normal exit */
}
/*
 * listen - child process to listen to port and
 *	     report everything heard
 */
listen()
{
	static char c;

	for ( ;; ) {	/* never stop -- until killed */
		c = 0;
		while ( read(pd,&c,1) != 1 ) {
		/*	sleep(2);	*/
			fprintf(stderr,"Read error\n");
		}
		write (1,&c,1);		/* echo the dude */
	}
}
/*
 * clisten - child process to listen to port with capture
 *           sigkill is used to terminate data capture gracefully
 */
sigkill()
{
	fclose(cfp);
	exit(0);
}
clisten(fp)
FILE *fp;
{
	static char c;

	signal ( SIGHUP, sigkill );

	for ( ;; ) {	/* never stop -- until killed */
		c = 0;
		while ( read(pd,&c,1) != 1 ) {
			fprintf(stderr,"Read error\n");
		}
		write (1,&c,1);		/* echo the dude */
		putc(c,fp);
	}
}
error (f,s)
char	*f, *s;
{
	fprintf(stderr,f,s);
	fprintf(stderr,"\n");
	bailout(1);
}
/*
 * bailout - exit with cleanup
 */
bailout ( code )
int	code;
{
	register t;

	if ( son ) {
		kill ( son, SIGHUP );
		while ( (t=wait((int *)NULL))!=-1 && t!=son )
			;
	}
	if ( pd ) {
		ioctl ( pd, TIOCSETP, &optty );
		close ( pd );
	}
	ioctl ( 0, TIOCSETP, &outty );
	exit ( code );
}
