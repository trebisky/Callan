/* This file is just a hook to add little things to the kernel
 *  tjt  2-26-87
 */

int	tjtclock = 0;

tjtintr()
{
	++tjtclock;
}
