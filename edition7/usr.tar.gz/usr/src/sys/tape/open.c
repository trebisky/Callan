main()
{
int x;
x=open("/dev/rmt0",0);
printf("open status = %d\n",x);
}
