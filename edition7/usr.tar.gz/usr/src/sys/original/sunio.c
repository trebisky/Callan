/* @(#)sunio.c	1.2
 *
 * Copyright 1982 UniSoft Corporation
 * Use of this material is subject to your disclosure agreement with AT&T,
 * Western Electric and UniSoft Corporation.
 *
 * Interface to the two on-board I/O ports on the sun workstation board
 */

#include <sys/ioctl.h>
#include <sys/param.h>
#include <sys/conf.h>
#include <sys/dir.h>
#include <sys/user.h>
#include <sys/tty.h>
#include <sys/systm.h>
#include <sys/unistar.h>

#define MHZ8
/* #define MHZ10 */

#define	SUNADDR	((struct device *)0x600000)
#define	NSUNIO	2

#ifdef MHZ8
#define CLK_B9600	13
#define S19P2	6
#define S9600	13
#define S4800	26
#define	S2400	52
#define	S1200	104
#define	S600	208
#define	S300	417
#endif

#ifdef MHZ10
#define CLK_B9600	8

#define S19P2	4
#define S9600	8
#define S4800	16
#define	S2400	32
#define	S1200	64
#define	S600	128
#define	S300	256
#endif

#define SUN0TIMER	4	/* Sun I/O port 0 */
#define SUN1TIMER	5	/* Sun I/O port 1 */

int sunspeed[] = {	/* lots of default to 9600...*/
	S9600, S9600, S9600, S9600, S9600, S9600, S9600, S300,
	S600, S1200, S9600, S2400, S4800, S9600, S19P2, S9600
};

#define XRDY	04	/* transmitter is ready */
#define DRDY	01	/* data is available */

struct	tty suntty[NSUNIO];
int	sunstart();
int	ttrstrt();
char	partab[];

struct device {
	char	dbuf;
	char	idum1;
	char	csr;
	char	idum2;
};

sunopen(dev, flag)
dev_t dev;
{
	register struct device *addr;
	register struct tty *tp;
	register d, s;

	d = minor(dev);
	if(d >= NSUNIO) {
		u.u_error = ENXIO;
		return;
	}
	tp = &suntty[d];
	addr = SUNADDR + d;
	tp->t_addr = (caddr_t)addr;
	tp->t_oproc = sunstart;
	s = spl6();
	if ((tp->t_state&ISOPEN) == 0) {
		if (tp->t_ispeed==0  &&  tp->t_ospeed==0) {
			tp->t_ispeed = tp->t_ospeed = B9600;
			tp->t_flags = ANYP|ECHO|XTABS|CRMOD;
			}
		sunparam(d);
		tp->t_state = ISOPEN|CARR_ON;
		ttychars(tp);
	}
#ifndef UCB_LDISC
	ttyopen(dev, tp);
#else UCB_LDISC
	(*linesw[tp->t_line].l_open)(dev, tp);
#endif UCB_LDISC
	splx(s);
}

sunclose(dev, flag)
dev_t dev;
int flag;
{
	register struct device *addr;
	register struct tty *tp;

	tp = &suntty[minor(dev)];
	addr = (struct device *)tp->t_addr;
#ifdef UCB_LDISC
	(*linesw[tp->t_line].l_close)(tp);
#endif UCB_LDISC
	ttyclose(tp);
}

sunread(dev)
dev_t dev;
{
#ifndef UCB_LDISC
	ttread(&suntty[minor(dev)]);
#else UCB_LDISC
	register struct tty *tp;

	tp = &suntty[minor(dev)];
	(*linesw[tp->t_line].l_read)(tp);
#endif UCB_LDISC
}

sunwrite(dev)
dev_t dev;
{
#ifndef UCB_LDISC
	ttwrite(&suntty[minor(dev)]);
#else UCB_LDISC
	register struct tty *tp;

	tp = &suntty[minor(dev)];
	(*linesw[tp->t_line].l_write)(tp);
#endif UCB_LDISC
}

sunintr()
{
	register struct device *addr;
	register struct tty *tp;
	register short i;

	if ((suntty[0].t_state&ISOPEN)==0 && (suntty[1].t_state&ISOPEN)==0)
		return;
	tp = &suntty[0];
	i = NSUNIO - 1;
	do {
		if ((tp->t_state&ISOPEN)==0) {
			tp++;
			continue;
		}
		addr = (struct device *)tp->t_addr;
		/* Check for incoming character */
		while (addr->csr & DRDY) 
			ttyinput(addr->dbuf, tp);

		/* Now send any outgoing chararacters */
		if (tp->t_outq.c_cc > 0) 
			(*linesw[tp->t_line].l_start)(tp);
		if((tp->t_state&(ASLEEP|TIMEOUT|TTSTOP|BUSY))==ASLEEP &&
		    tp->t_outq.c_cc <= TTLOWAT)
			wakeup((caddr_t)&tp->t_outq);
		tp++;
    	} while (--i != -1);
}

sunstart(tp)
register struct tty *tp;
{
	register struct device *addr;
	register int c;

	addr = (struct device *)tp->t_addr;
	while ((addr->csr & XRDY) && (c = getc(&tp->t_outq)) >= 0)
		addr->dbuf = c & 0xFF;
}

sunioctl(dev, cmd, addr, flag)
caddr_t addr;
dev_t dev;
{
	register struct tty *tp;

	tp = &suntty[minor(dev)];
	if ((*linesw[tp->t_line].l_ioctl)(tp, cmd, addr, flag) ) {
		if (cmd == TIOCSETP || cmd == TIOCSETN)
			sunparam(dev);
	}
	else
		u.u_error = ENOTTY;
}

sunparam(dev)
dev_t dev;
{
	register struct tty * tp = &suntty[minor(dev)];
	register struct device * addr = (struct device *)tp->t_addr;
	register d = sunspeed[tp->t_ospeed];
	register s = spl6();

	addr->csr = 0x18; addr->csr = 0x18;	/* UART channel reset */
	addr->csr = 2; addr->csr = 0x00;	/* priority of ints. */
	addr->csr = 4; addr->csr = 0x44;
	addr->csr = 3; addr->csr = 0xC1;
	addr->csr = 5; addr->csr = 0xEA;
	addr->csr = 1; addr->csr = 0x00;
	if (tp == &suntty[0]) {
		CLKADDR->clk_cmd = CLK_LMODE+SUN0TIMER;	/* load-mode */
		CLKADDR->clk_data = CLK_MODE;		/* set mode */
		CLKADDR->clk_cmd = CLK_LLOAD+SUN0TIMER;	/* load-reg */
		CLKADDR->clk_data = d;		/* set ld reg */
		CLKADDR->clk_cmd = CLK_GO+0x08;		/* enable clk */
	} else {
		CLKADDR->clk_cmd = CLK_LMODE+SUN1TIMER;	/* load-mode */
		CLKADDR->clk_data = CLK_MODE;		/* set mode */
		CLKADDR->clk_cmd = CLK_LLOAD+SUN1TIMER;	/* load-reg */
		CLKADDR->clk_data = d;		/* set ld reg */
		CLKADDR->clk_cmd = CLK_GO+0x10;		/* enable clk */
	}
	splx(s);
}

/*
 * This version of putchar writes directly to the on-board port 1
 * using busy-wait and no interrupt for those last-ditch situations
 * when you just have to get stuff to the CRT.
 */
sunputchar(c)
register c;
{
	register struct device *addr;
	register int timo;
	static suninit;

	addr = SUNADDR;
	if (suninit == 0) {
		suninit = 1;
		addr->csr = 0x18; addr->csr = 0x18;	/* UART reset */
		addr->csr = 2; addr->csr = 0x00;
		addr->csr = 4; addr->csr = 0x44;
		addr->csr = 3; addr->csr = 0xC1;
		addr->csr = 5; addr->csr = 0xEA;
		addr->csr = 1; addr->csr = 0x00;
		CLKADDR->clk_cmd = CLK_LMODE+SUN0TIMER;	/* load-mode */
		CLKADDR->clk_data = CLK_MODE;		/* set mode */
		CLKADDR->clk_cmd = CLK_LLOAD+SUN0TIMER;	/* load-reg */
		CLKADDR->clk_data = CLK_B9600;		/* set ld reg */
		CLKADDR->clk_cmd = CLK_GO+0x08;		/* enable clk */
	}
	if (c != '\0' && c != '\r' && c != 0177) {
		*msgbufp++ = c;
		if (msgbufp >= &msgbuf[MSGBUFS])
			msgbufp = msgbuf;
	}
	timo = 200000;
	/*
	 * Wait for console to become ready in some
	 * reasonable time, otherwise wash hands
	 */
	while ((addr->csr & XRDY) == 0)
		if (--timo <= 0)
			break;
	if (c == 0) 
		return;
	addr->dbuf = c & 0xFF;
	if (c == '\n')
		sunputchar('\r');
	sunputchar(0);
}
