#include <sys/param.h>
#include <sys/unistar.h>
#include <sys/buf.h>
#include <sys/systm.h>
#include <sys/dir.h>
#include <sys/user.h>
#include <sys/ioctl.h>
#include <setjmp.h>
#include <local/ctypes.h>

static	U8	swzero = 0;

swinterrupt(device)
	dev_t	device;
	{
	U8     *ioports;
	U8	status;
	int	a,b;

	mscdump();
	ioports = (U8 *)SWICMDP_VA;
	status  = *ioports;
	/*   *ioports = swzero;  */
	printf("\nSWI: status = %x\n",status);
	}
