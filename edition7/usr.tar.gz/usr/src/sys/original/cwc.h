/*****************************************************************************
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *      File:           cwc.h                                                *
 *                                                                           *
 *      Description:    UNIX (V7) I/O driver for the Callan Data Systems     *
 *                      Winchester (ST-506) disk controller.                 *
 *                                                                           *
 *      Author:         Philip K. Ronzone                                    *
 *                      Callan Data Systems, Inc.                            *
 *                      2637 Townsgate Road                                  *
 *                      Westlake Village,  CA    91361                       *
 *                      (805)-497-6837                                       *
 *                                                                           *
 *      Date:           08-Nov-82.                                           *
 *                      18-Feb-83.                                           *
 *                                                                           *
 *    +-------------------------------------------------------------------+  *
 *    | Notice:         THIS IS PROPRIETARY INFORMATION OF Callan Data    |  *
 *    |                 Systems Incorporated, AND THE USE, DUPLICATION    |  *
 *    |                 OR DISCLOSURE OF THIS SOURCE FILE AND INFORMATION |  *
 *    |                 CONTAINED HEREIN IS RESTRICTED TO Callan Data     |  *
 *    |                 Systems Incorporated EMPLOYEES AND THOSE OTHERS   |  *
 *    |                 WHO HAVE EXPLICIT AND PRIOR WRITTEN AGREEMENTS TO |  *
 *    |                 USE THIS MATERIAL.                                |  *
 *    +-------------------------------------------------------------------+  *
 *                                                                           *
 *      Copyright:      Copyright 1982 by Callan Data Systems, Inc.          *
 *                      Copyright 1983 by Callan Data Systems, Inc.          *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *****************************************************************************/

typedef struct                  /* THE DISK DRIVE SPECIFICATIONS.       */
        {                       /* ==================================== */
        U8      dds_nspt;       /* Number of sectors per track.         */
        U8      dds_ntpc;       /* Number of tracks per cylinder.       */
        U16     dds_ncpd;       /* Number of cylinders per drive.       */
        U16     dds_nspc;       /* Number of sectors per cylinder.      */
	U16	dds_dcrw;	/* Cylinder for reduced write current.	*/
	U16	dds_dcwp;	/* Cylinder for write precompensation.	*/
        U8      dds_step;       /* Step rate for the drive.             */
        U8      dds_rstr;       /* Restore step rate for the drive.	*/
        }       DDS;            /* ==================================== */

typedef struct                  /* THE FILESYSTEM MAPPER.               */
        {                       /* ==================================== */
        U32     fsm_sblk;       /* Starting block number.               */
        U32     fsm_eblk;       /* Ending block number.                 */
        U8      fsm_good;       /* Valid filesystem?   (NO == 0).       */
        U8      fsm_vrfy;       /* Verify after write? (NO == 0).       */
        U8      fsm_ualt;       /* Use alternate sectoring (NO == 0).	*/
        U8      fsm_rerm;       /* Report errors on console? (NO == 0).	*/
        }       FSM;            /* ==================================== */
