/*****************************************************************************
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *      File:           cwcspecs.c                                           *
 *                                                                           *
 *      Description:    UNIX (V7) I/O driver for the Callan Data Systems     *
 *                      Winchester (ST-506) disk controller.                 *
 *                                                                           *
 *      Author:         Philip K. Ronzone                                    *
 *                      Callan Data Systems, Inc.                            *
 *                      2637 Townsgate Road                                  *
 *                      Westlake Village,  CA    91361                       *
 *                      (805)-497-6837                                       *
 *                                                                           *
 *      Date:           08-Nov-82.                                           *
 *                      18-Feb-83.                                           *
 *                                                                           *
 *    +-------------------------------------------------------------------+  *
 *    | Notice:         THIS IS PROPRIETARY INFORMATION OF Callan Data    |  *
 *    |                 Systems Incorporated, AND THE USE, DUPLICATION    |  *
 *    |                 OR DISCLOSURE OF THIS SOURCE FILE AND INFORMATION |  *
 *    |                 CONTAINED HEREIN IS RESTRICTED TO Callan Data     |  *
 *    |                 Systems Incorporated EMPLOYEES AND THOSE OTHERS   |  *
 *    |                 WHO HAVE EXPLICIT AND PRIOR WRITTEN AGREEMENTS TO |  *
 *    |                 USE THIS MATERIAL.                                |  *
 *    +-------------------------------------------------------------------+  *
 *                                                                           *
 *      Copyright:      Copyright 1982 by Callan Data Systems, Inc.          *
 *                      Copyright 1983 by Callan Data Systems, Inc.          *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *                                                                           *
 *****************************************************************************/

#include <local/ctypes.h>
#include "cwc.h"

/*
 *      This is the disk drive specification (DDS) table. Each disk drive
 *      has it's own entry in this table, indexed by it's drive number.
 *      The purpose of this table is to map each different kind of drive
 *      into a single range of absolute, 512-byte block numbers.  Each
 *      drive can then be thought of as containing `N' 512-byte blocks,
 *      that range from block number 0 through block number `N'-1.
 *
 *      Each file system map (the FSM table, see below) maps a logical
 *      set of blocks from the file system into a physical range of
 *      blocks on the disk drive.
 *
 *
 *
 *  Restore stepping rate value ------------------------------------+
 *  Normal stepping rate value --------------------------------+    |
 *  Cylinder for write precompensation -------------------+    |    |
 *  Cylinder for reduced write current --------------+    |    |    |
 *  Number of sectors per cylinder ------------+     |    |    |    |
 *  Number of cylinders per drive --------+    |     |    |    |    |
 *  Number of heads per drive ---------+  |    |     |    |    |    |
 *  Number of sectors per track ---+   |  |    |     |    |    |    |
 *                                 |   |  |    |     |    |    |    |
 *                                 |   |  |    |     |    |    |    |
 *                                 V   V  V    V     V    V    V    V
 */
#ifdef RACKSYS
        DDS     cwcdrctl[4]  =  { {17, 8, 320, 17*8, 132, 000,  12, 158},
                                  {17, 8, 320, 17*8, 132, 000,  12, 158},
                                  {17, 4, 656, 17*4, 700, 000,  12, 158},
                                  {17, 4, 320, 17*4, 132, 000,  12, 158}
                                };
#endif
#ifdef CWC202
        DDS     cwcdrctl[4]  =  { {17, 4, 320, 17*4, 132, 000,  12, 158},
                                  {17, 4, 320, 17*4, 132, 000,  12, 158},
                                  {17, 4, 320, 17*4, 132, 000,  12, 158},
                                  {17, 4, 320, 17*4, 132, 000,  12, 158}
                                };
#endif
#ifdef CWC204
        DDS     cwcdrctl[4]  =  { {17, 8, 320, 17*8, 132, 000,  12, 158},
                                  {17, 8, 320, 17*8, 132, 000,  12, 158},
                                  {17, 8, 320, 17*8, 132, 000,  12, 158},
                                  {17, 8, 320, 17*8, 132, 000,  12, 158}
                                };
#endif

/*
 *      This is the filesystem mapper (FSM) table.  Each possible filesystem
 *      has an entry in this table.  Each entry has two values in it.
 *      The first value is the starting physical block number of the
 *      filesystem.  The second value is the ending physical block number
 *      of the filesystem.
 *
 *      Thus, the maximum number of logical blocks for the filesystem
 *      may be calculated by:
 *
 *          ending_physical_blkno - starting_physical_blkno + 1
 *
 *      Each logical block of the filesystem has the starting physical
 *      block number of the filesystem added to it.  Thus, a filesystem
 *      is mapped onto a disk drive entirely by a starting and ending 
 *      physical block number.  If you want to align a filesystem on a
 *      cylinder boundary or whatnot, you must calculate the appropriate
 *      physical starting block number by hand.  Even then, depending on
 *      the disk drive specification table (DDS) table, you may not be able
 *      to ensure that such a boundary can be found for all types of disk
 *      drives.
 *
 *      Then again, there are 64 possible entries, so a degenerate mapping
 *      of various filesystem should take care of these kind of mapping
 *      problems.
 *
 *
 *
 *  Print out error messages on the console (NO == 0) ----------------------+
 *  Use alternate sectoring (NO == 0) ----------------------------------+   |
 *  Verify after write (NO == 0) -----------------------------------+   |   |
 *  File system valid  (NO == 0) -------------------------------+   |   |   |
 *  Ending physical block number ------------------------+      |   |   |   |
 *  Starting physical block number -----------------+    |      |   |   |   |
 *                                                  |    |      |   |   |   |
 *                                                  V    V      V   V   V   V
 */
FSM	cwcmap[64]={
/* 00 Rodime RO 202 (320,4,17)bblk 000-001 */ {     0,    135,  1,  1,  0,  1},
/* 01 Rodime RO 202 (320,4,17)a    002-143 */ {   136,   9791,  1,  1,  1,  1},
/* 02 Rodime RO 202 (320,4,17)swap 144-163 */ {  9792,  11151,  1,  1,  1,  1},
/* 03 Rodime RO 202 (320,4,17)b    164-319 */ { 11152,  21759,  1,  1,  1,  1},
/* 04 Rodime RO 202 (320,4,17)z    002-319 */ {   136,  21759,  1,  1,  1,  1},
/* 05 Rodime RO 202 (320,4,17)init 000-319 */ {     0,  21759,  1,  1,  0,  0},
/* 06                                      */ {     0,      0,  0,  0,  0,  0},
/* 07                                      */ {     0,      0,  0,  0,  0,  0},
/* 08                                      */ {     0,      0,  0,  0,  0,  0},
/* 09                                      */ {     0,      0,  0,  0,  0,  0},
/* 10 Rodime RO 204 (320,8,17)bblk 000-000 */ {     0,    135,  1,  1,  0,  1},
/* 11 Rodime RO 204 (320,8,17)a    001-091 */ {   136,  12511,  1,  1,  1,  1},
/* 12 Rodime RO 204 (320,8,17)swap 092-127 */ { 12512,  17407,  1,  1,  1,  1},
/* 13 Rodime RO 204 (320,8,17)b    128-319 */ { 17408,  43519,  1,  1,  1,  1},
/* 14 Rodime RO 204 (320,8,17)z    001-319 */ {   136,  43519,  1,  1,  1,  1},
/* 15 Rodime RO 204 (320,8,17)init 000-319 */ {     0,  43519,  1,  1,  0,  0},
/* 16                                      */ {     0,      0,  0,  0,  0,  0},
/* 17                                      */ {     0,      0,  0,  0,  0,  0},
/* 18                                      */ {     0,      0,  0,  0,  0,  0},
/* 19                                      */ {     0,      0,  0,  0,  0,  0},
/* 20 CDC 9415 (697,5,17) bblk     000-000 */ {     0,     84,  1,  1,  0,  1},
/* 21 CDC 9415 (697,5,17) a        001-114 */ {    85,   9774,  1,  1,  1,  1},
/* 22 CDC 9415 (697,5,17) swap     115-176 */ {  9775,  15044,  1,  1,  1,  1},
/* 23 CDC 9415 (697,5,17) b        177-655 */ { 15045,  55759,  1,  1,  1,  1},
/* 24 CDC 9415 (697,5,17) z        001-655 */ {    85,  55759,  1,  1,  1,  1},
/* 25 CDC 9415 (697,5,17) init     000-655 */ {     0,  55759,  1,  1,  0,  0},
/* 26                                      */ {     0,      0,  0,  0,  0,  0},
/* 27                                      */ {     0,      0,  0,  0,  0,  0},
/* 28                                      */ {     0,      0,  0,  0,  0,  0},
/* 29                                      */ {     0,      0,  0,  0,  0,  0},
/* 30                                      */ {     0,      0,  0,  0,  0,  0},
/* 31                                      */ {     0,      0,  0,  0,  0,  0},
/* 32                                      */ {     0,      0,  0,  0,  0,  0},
/* 33                                      */ {     0,      0,  0,  0,  0,  0},
/* 34                                      */ {     0,      0,  0,  0,  0,  0},
/* 35                                      */ {     0,      0,  0,  0,  0,  0},
/* 36                                      */ {     0,      0,  0,  0,  0,  0},
/* 37                                      */ {     0,      0,  0,  0,  0,  0},
/* 38                                      */ {     0,      0,  0,  0,  0,  0},
/* 39                                      */ {     0,      0,  0,  0,  0,  0},
/* 40                                      */ {     0,      0,  0,  0,  0,  0},
/* 41                                      */ {     0,      0,  0,  0,  0,  0},
/* 42                                      */ {     0,      0,  0,  0,  0,  0},
/* 43                                      */ {     0,      0,  0,  0,  0,  0},
/* 44                                      */ {     0,      0,  0,  0,  0,  0},
/* 45                                      */ {     0,      0,  0,  0,  0,  0},
/* 46                                      */ {     0,      0,  0,  0,  0,  0},
/* 47                                      */ {     0,      0,  0,  0,  0,  0},
/* 48                                      */ {     0,      0,  0,  0,  0,  0},
/* 49                                      */ {     0,      0,  0,  0,  0,  0},
/* 50                                      */ {     0,      0,  0,  0,  0,  0},
/* 51                                      */ {     0,      0,  0,  0,  0,  0},
/* 52                                      */ {     0,      0,  0,  0,  0,  0},
/* 53                                      */ {     0,      0,  0,  0,  0,  0},
/* 54                                      */ {     0,      0,  0,  0,  0,  0},
/* 55                                      */ {     0,      0,  0,  0,  0,  0},
/* 56                                      */ {     0,      0,  0,  0,  0,  0},
/* 57                                      */ {     0,      0,  0,  0,  0,  0},
/* 58                                      */ {     0,      0,  0,  0,  0,  0},
/* 59                                      */ {     0,      0,  0,  0,  0,  0},
/* 60                                      */ {     0,      0,  0,  0,  0,  0},
/* 61                                      */ {     0,      0,  0,  0,  0,  0},
/* 62                                      */ {     0,      0,  0,  0,  0,  0},
/* 63                                      */ {     0,      0,  0,  0,  0,  0},
                                              };
