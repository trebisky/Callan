char _Version_[] = "Copyright 1983 by Callan Data Systems, Incorporated.";

#include <sys/param.h>
#include <sys/unistar.h>
#include <sys/systm.h>
#include <sys/buf.h>
#include <sys/tty.h>
#include <sys/conf.h>
#include <sys/context.h>
#include <sys/proc.h>
#include <sys/text.h>
#include <sys/dir.h>
#include <sys/file.h>
#include <sys/inode.h>
#include <sys/acct.h>
#include <sys/map.h>

#ifdef CFCSYS
#   ifndef CFC
#   define CFC
#   endif
#endif
#ifdef CFC
int		cfcopen();
int		cfcstrategy();
int		cfcread();
int		cfcwrite();
int		cfcioctl();
struct	buf	cfcqueue;
#endif

#ifdef MSC202
#   ifndef MSC
#   define MSC
#   endif
#endif
#ifdef MSC204
#   ifndef MSC
#   define MSC
#   endif
#endif
#ifdef MSC
int		mscopen();
int		mscstrategy();
int		mscread();
int		mscwrite();
int		mscioctl();
struct	buf	mscqueue;
#endif

#ifdef CWC202
#   ifndef CWC
#   define CWC
#   endif
#endif
#ifdef CWC204
#   ifndef CWC
#   define CWC
#   endif
#endif
#ifdef CWC9415
#   ifndef CWC
#   define CWC
#   endif
#endif
#ifdef CWC
int		cwcopen();
int		cwcstrategy();
int		cwcread();
int		cwcwrite();
int		cwcioctl();
struct	buf	cwcqueue;
#endif

#ifdef TAPEMSTR
int		tmopen ();
int		tmclose ();
int		tmstrategy ();
int		tmread ();
int		tmwrite ();
int		tmioctl ();
struct buf	tmqueue;
#endif

#ifdef SMD
int		smdopen ();
int		smdstrategy ();
int		smdread ();
int		smdwrite ();
int		smdioctl ();
struct buf	smdqueue;
#endif

int		mmread();
int		mmwrite();

int		nulldev();
int		nodev();



struct  bdevsw  bdevsw[]  =
    {
#ifdef MSC
    mscopen, nulldev, mscstrategy, &mscqueue,	/* 0 - MSC winchester */
#else
    nulldev, nulldev, nulldev,     0,		/* 0 - MSC winchester */
#endif
#ifdef CFC
    cfcopen, nulldev, cfcstrategy, &cfcqueue,	/* 1 - Callan floppy */
#else
    nulldev, nulldev, nulldev,     0,		/* 1 - Callan floppy */
#endif
#ifdef CWC
    cwcopen, nulldev, cwcstrategy, &cwcqueue,	/* 2 - Callan winchester */
#else
    nulldev, nulldev, nulldev,     0,		/* 2 - Callan winchester */
#endif
    nulldev, nulldev, nulldev,     0,		/* 3 - CGC ram "disk"  */
    nulldev, nulldev, nulldev,     0,		/* 4 - Reserved */
    nulldev, nulldev, nulldev,     0,		/* 5 - Reserved */
    nulldev, nulldev, nulldev,     0,		/* 6 - Reserved */
    nulldev, nulldev, nulldev,     0,		/* 7 - Reserved */
    nulldev, nulldev, nulldev,     0,		/* 8 - Reserved */
    nulldev, nulldev, nulldev,     0,		/* 9 - Reserved */
#ifdef TAPEMSTR
    tmopen,  tmclose, tmstrategy,  &tmqueue,	/* 10 - Tapemaster tape */
#else
    nulldev, nulldev, nulldev,     0,		/* 10 - Tapemaster tape */
#endif
#ifdef SMD
    smdopen, nulldev, smdstrategy, &smdqueue,	/* 11 - Intel SMD */
#else
    nulldev, nulldev, nulldev,     0,		/* 11 - Intel SMD */
#endif
    nulldev, nulldev, nulldev,     0,		/* 12 - Ethernet */
    0
    };

int	sunopen(), sunclose(), sunread(), sunwrite(), sunioctl();
int	syopen(), syread(), sywrite(), sysioctl();
#ifdef CGC
int	cgcopen(), cgcclose(), cgcread(), cgcwrite(), cgcioctl();
#endif
#ifdef QUAD
int	quadopen(), quadclose(), quadread(), quadwrite(), quadioctl();
#endif

struct	cdevsw	cdevsw[]  =
    {
    sunopen, sunclose, sunread, sunwrite, sunioctl, nulldev, 0, /* 0 - SUN */
    syopen,  nulldev,  syread,  sywrite,  sysioctl, nulldev, 0, /* 1 - TTY */
    nulldev, nulldev,  mmread,  mmwrite,  nodev,    nulldev, 0, /* 2 - MEM */
#ifdef QUAD
    quadopen,quadclose,quadread,quadwrite,quadioctl,nulldev, 0, /* 3 - QUAD */
#else
    nulldev, nulldev,  nulldev, nulldev,  nodev,    nulldev, 0, /* 3 - QUAD */
#endif
#ifdef CFC
    cfcopen, nulldev,  cfcread, cfcwrite, cfcioctl, nulldev, 0, /* 4 - CFC */
#else
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 4 - CFC */
#endif
#ifdef MSC
    mscopen, nulldev,  mscread, mscwrite, mscioctl, nulldev, 0, /* 5 - MSC */
#else
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 5 - MSC */
#endif
#ifdef CWC
    cwcopen, nulldev,  cwcread, cwcwrite, cwcioctl, nulldev, 0, /* 6 - CWC */
#else
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 6 - CWC */
#endif
#ifdef CGC
    cgcopen, cgcclose, cgcread, cgcwrite, cgcioctl, nulldev, 0, /* 7 - CGC */
#else
    nulldev, nulldev,  nulldev, nulldev,  nodev,    nulldev, 0, /* 7 - CGC */
#endif
    nulldev, nulldev,  nulldev, nulldev,  nodev,    nulldev, 0, /* 8 - rsrvd */
    nulldev, nulldev,  nulldev, nulldev,  nodev,    nulldev, 0, /* 9 - rsrvd */
#ifdef TAPEMSTR
    tmopen,  tmclose,  tmread,  tmwrite,  tmioctl,  nulldev, 0, /* 10 - tape */
#else
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 10 - tape */
#endif
#ifdef SMD
    smdopen, nulldev,  smdread, smdwrite, smdioctl, nulldev, 0, /* 11 - SMD */
#else
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 11 - SMD */
#endif
    nulldev, nulldev,  nulldev, nulldev,  nulldev,  nulldev, 0, /* 12 - Enet */
    0
    };

int	ttyopen(), ttyclose(), ttread(), ttyinput(), ttstart();
char	*ttwrite();
int	ttioctl();

struct	linesw	linesw[] = {
	ttyopen, ttyclose, ttread, ttwrite, ttioctl, ttyinput, nulldev, /* 0 */
	nulldev, ttstart, nulldev,
};

#ifdef MSC202
char oemmsg[] =
"\033[2J\033\[HCallan Data Systems UNISTAR UNIX Release 3.0 (MSC 10MB)\n";
#   ifdef CFCSYS
dev_t	rootdev	= makedev(1, 0);
dev_t	pipedev = makedev(1, 0);
#   else
dev_t	rootdev	= makedev(0, 0);
dev_t	pipedev = makedev(0, 0);
#   endif
dev_t	swapdev	= makedev(0, 0);
daddr_t	swplo	= 6464;
int	nswap	= 3136;
#endif
#ifdef MSC204
char oemmsg[] =
"\033[2J\033\[HCallan Data Systems UNISTAR UNIX Release 3.0 (MSC 21MB)\n";
#   ifdef CFCSYS
dev_t	rootdev	= makedev(1, 0);
dev_t	pipedev = makedev(1, 0);
#   else
dev_t	rootdev	= makedev(0, 0);
dev_t	pipedev = makedev(0, 0);
#   endif
dev_t	swapdev	= makedev(0, 0);
daddr_t	swplo	= 6464;
int	nswap	= 3136;
#endif
#ifdef CWC202
char oemmsg[] =
"\033[2J\033\[HCallan Data Systems UNISTAR UNIX Release 3.0 (CWC 10MB)\n";
#   ifdef CFCSYS
dev_t	rootdev	= makedev(1, 0);
dev_t	pipedev = makedev(1, 0);
#   else
dev_t	rootdev	= makedev(2, 1);
dev_t	pipedev = makedev(2, 1);
#   endif
dev_t	swapdev	= makedev(2, 2);
daddr_t	swplo	= 0;
int	nswap	= 1360;
#endif
#ifdef CWC204
char oemmsg[] =
"\033[2J\033\[HCallan Data Systems UNISTAR UNIX Release 3.0 (CWC 21MB)\n";
#   ifdef CFCSYS
dev_t	rootdev	= makedev(1, 0);
dev_t	pipedev = makedev(1, 0);
#   else
dev_t	rootdev	= makedev(2, 11);
dev_t	pipedev = makedev(2, 11);
#   endif
dev_t	swapdev	= makedev(2, 12);
daddr_t	swplo	= 0;
int	nswap	= 4896;
#endif
#ifdef CWC9415
char oemmsg[] =
"\033[2J\033\[HCallan Data Systems UNISTAR UNIX Release 3.0 (CWC 28MB)\n";
#   ifdef CFCSYS
dev_t	rootdev	= makedev(1, 0);
dev_t	pipedev = makedev(1, 0);
#   else
dev_t	rootdev	= makedev(2, 21);
dev_t	pipedev = makedev(2, 21);
#   endif
dev_t	swapdev	= makedev(2, 22);
daddr_t	swplo	= 0;
int	nswap	= 5270;
#endif

int	nldisp  = 1;
int	hz	= HZ;		/* internal clock frequency */
int	small   = 1;		/* set to zero to disable multibus memory */
int	usrtop  = btoc(UEND);	/* default end of user memory */
int	timezone= TIMEZONE;	/* time zone */
int	dstflag = DSTFLAG;	/* daylight flag */
	
int	sunputchar();
int	(*putchar)() = sunputchar;
int	mpxchan();
int	(*ldmpx)() = mpxchan;

char	*msgbufp = msgbuf;	/* Next saved printf character */

struct	buf		buf[NBUF];
struct	file		file[NFILE];
struct	inode		inode[NINODE];
struct	proc		proc[NPROC];
struct	text		text[NTEXT];
struct	context		context[NUMCONTX];
struct	locklist	locklist[NFLOCKS];
struct	buf		bfreelist;
struct	acct	        acctbuf;
struct	inode	       *acctp;

/*
 * configuration variables
 */
int v_nbuf	= NBUF;		/* Number of system buffers.		*/
int v_nfile	= NFILE;	/* Size of in core file table.		*/
int v_ninode	= NINODE;	/* Size of in core inode table.		*/
int v_nproc	= NPROC;	/* Size of in core process table.	*/
int v_ntext	= NTEXT;	/* Size of in core text table.		*/
int v_ustart	= USTART;	/* Base address for user programs.	*/
int v_bsize	= BSIZE;	/* Size of each buffer.			*/

/*
 * Perform user defined initialization functions
 */
sysinit()
{
	/*
	 * Free context page map.
	 *
	 * There are a total of 64 segments supported by the MMU.
	 * A total of 59 segments are freed starting at segment 4.
	 * Segment 0-3 and segment 63 are permanently used by the system.
	 *
	 * To use the 62nd segment change 59 to 58 and set up the pages
	 * associated with that context. All of the virtual segments
	 * are mapped 1 to 1 by the kernel startup code.
	 * UEND in /usr/include/sys/param.h must also be decreased by 32K.
	 */

	mfree(cxmap, 59-4, 4);
}
