
typedef	unsigned	char	U8;
typedef	unsigned	short	U16;
typedef	unsigned	int	U32;
typedef			char	S8;
typedef			short	S16;
typedef			int	S32;
