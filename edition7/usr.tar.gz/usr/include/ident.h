char myname [] = "Pacific Microcomputers 68000 Unix";
