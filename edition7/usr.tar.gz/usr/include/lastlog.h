struct lastlog {
	time_t	ll_time;
	char	ll_line[8];
};
