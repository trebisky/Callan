/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

struct fblk
{
	short  	df_nfree;
	daddr_t	df_free[NICFREE];
};
