/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

/*	ioctl.h	3.7	7/18/80	*/
/*
 * ioctl definitions, and special character and local tty definitions
 */
#ifndef	_IOCTL_
#define	_IOCTL_
struct tchars {
	char	t_intrc;	/* interrupt */
	char	t_quitc;	/* quit */
	char	t_startc;	/* start output */
	char	t_stopc;	/* stop output */
	char	t_eofc;		/* end-of-file */
	char	t_brkc;		/* input delimiter (like nl) */
};
struct ltchars {
	char	t_suspc;	/* stop process signal */
	char	t_dsuspc;	/* delayed stop process signal */
	char	t_rprntc;	/* reprint line */
	char	t_flushc;	/* flush output (toggles) */
	char	t_werasc;	/* word erase */
	char	t_lnextc;	/* literal next character */
	char	t_lerase;	/* local erase */
	char	t_lkill;	/* local kill */
	char	t_lintr;	/* local interrupt */
};

/*
 * local mode settings
 */
#define	LCRTBS	01		/* correct backspacing for crt */
#define	LPRTERA 02		/* printing terminal \ ... / erase */
#define	LCRTERA	04		/* do " \b " to wipe out character */
#define	LTILDE	010		/* IIASA - hazeltine tilde kludge */
#define	LMDMBUF	020		/* IIASA - start/stop output on carrier intr */
#define	LLITOUT	040		/* IIASA - suppress any output translations */
#define	LTOSTOP	0100		/* send stop for any background tty output */
#define	LFLUSHO	0200		/* flush output sent to terminal */
#define	LNOHANG 0400		/* IIASA - don't send hangup on carrier drop */
#define	LETXACK 01000		/* IIASA - diablo style buffer hacking */
#define	LCRTKIL	02000		/* erase whole line on kill with " \b " */
#define	LINTRUP 04000		/* interrupt on every input char - SIGTINT */
#define	LCTLECH	010000		/* echo control characters as ^X */
#define	LPENDIN	020000		/* tp->t_rawq is waiting to be reread */

/* local state */
#define	LSBKSL	01		/* state bit for lowercase backslash work */
#define	LSQUOT	02		/* last character input was \ */
#define	LSERASE	04		/* within a \.../ for LPRTRUB */
#define	LSLNCH	010		/* next character is literal */
#define	LSTYPEN	020		/* retyping suspended input (LPENDIN) */

/*
 * tty ioctl commands
 */
#define	TIOCGETD	(('t'<<8)|0)	/* get line discipline */
#define	TIOCSETD	(('t'<<8)|1)	/* set line discipline */
#define	TIOCHPCL	(('t'<<8)|2)	/* set hangup line on close bit */
#define	TIOCMODG	(('t'<<8)|3)	/* modem bits get (???) */
#define	TIOCMODS	(('t'<<8)|4)	/* modem bits set (???) */
#define	TIOCGETP	(('t'<<8)|8)	/* get parameters - like old gtty */
#define	TIOCSETP	(('t'<<8)|9)	/* set parameters - like old stty */
#define	TIOCSETN	(('t'<<8)|10)	/* set params w/o flushing buffers */
#define	TIOCEXCL	(('t'<<8)|13)	/* set exclusive use of tty */
#define	TIOCNXCL	(('t'<<8)|14)	/* reset exclusive use of tty */
#define	TIOCFLUSH	(('t'<<8)|16)	/* flush buffers */
#define	TIOCSETC	(('t'<<8)|17)	/* set special characters */
#define	TIOCGETC	(('t'<<8)|18)	/* get special characters */
/* locals, from 127 down */
#define	TIOCLBIS	(('t'<<8)|127)	/* bis local mode bits */
#define	TIOCLBIC	(('t'<<8)|126)	/* bic local mode bits */
#define	TIOCLSET	(('t'<<8)|125)	/* set entire local mode word */
#define	TIOCLGET	(('t'<<8)|124)	/* get local modes */
#define	TIOCSBRK	(('t'<<8)|123)	/* set break bit */
#define	TIOCCBRK	(('t'<<8)|122)	/* clear break bit */
#define	TIOCSDTR	(('t'<<8)|121)	/* set data terminal ready */
#define	TIOCCDTR	(('t'<<8)|120)	/* clear data terminal ready */
#define	TIOCGPGRP	(('t'<<8)|119)	/* get pgrp of tty */
#define	TIOCSPGRP	(('t'<<8)|118)	/* set pgrp of tty */
#define	TIOCSLTC	(('t'<<8)|117)	/* set local special characters */
#define	TIOCGLTC	(('t'<<8)|116)	/* get local special characters */
#define	TIOCOUTQ	(('t'<<8)|115)	/* number of chars in output queue */

#define	NTTYDISC	1

#define	DIOCLSTN	(('d'<<8)|1)
#define	DIOCNTRL	(('d'<<8)|2)
#define	DIOCMPX		(('d'<<8)|3)
#define	DIOCNMPX	(('d'<<8)|4)
#define	DIOCSCALL	(('d'<<8)|5)
#define	DIOCRCALL	(('d'<<8)|6)
#define	DIOCPGRP	(('d'<<8)|7)
#define	DIOCGETP	(('d'<<8)|8)
#define	DIOCSETP	(('d'<<8)|9)
#define	DIOCLOSE	(('d'<<8)|10)
#define	DIOCTIME	(('d'<<8)|11)
#define	DIOCRESET	(('d'<<8)|12)
#define	DIOCSMETA	(('d'<<8)|13)
#define	DIOCMERGE	(('d'<<8)|14)
#define	DIOCICHAN	(('d'<<8)|15)
#define	DIOCPAD		(('d'<<8)|16)
#define	DIOCRMETA	(('d'<<8)|17)
#define	DIOCXOUT	(('d'<<8)|18)
#define	DIOCBMETA	(('d'<<8)|19)
#define	DIOCAMETA	(('d'<<8)|20)
#define	DIOCSBMETA	(('d'<<8)|21)

#define	FIOCLEX		(('f'<<8)|1)
#define	FIONCLEX	(('f'<<8)|2)
/* another local */
#define	FIONREAD	(('f'<<8)|127)	/* get # bytes to read */
/* FIONREAD is not implemented on mpx channels yet */

#define	MXLSTN		(('x'<<8)|1)
#define	MXNBLK		(('x'<<8)|2)

/*
 * These are defined in sys/vcmd.h
 *
#define	VGETSTATE	(('v'<<8)|0)
#define	VSETSTATE	(('v'<<8)|1)
 */
#endif

#define IOCFORMAT	(('i'<<8)|0)	/* format disk */
#define IOCEXTE		(('i'<<8)|1)
#define IOCNEXTE	(('i'<<8)|2)
#define IOCWCHK		(('i'<<8)|3)
#define IOCNWCHK	(('i'<<8)|4)
#define IOCGETP		(('i'<<8)|8)
#define IOCSETP		(('i'<<8)|9)
#define IOCBDBK		(('i'<<8)|10)

/*
 *  Disk driver ioctl() command codes.
 */

#define	IOCFMTST        (('i'<<8)|101)	/* Format disk (specific trks). */
#define	IOCVON		(('i'<<8)|102)	/* Turn write verify on.	*/
#define	IOCVOFF		(('i'<<8)|103)	/* Turn write verify off.	*/
#define	IOCVSTAT	(('i'<<8)|104)	/* Report write verify status.	*/
#define	IOCFSSET	(('i'<<8)|105)	/* Set filesystem spec's.	*/
#define	IOCFSGET	(('i'<<8)|106)	/* Get filesystem spec's.	*/
#define	IOCDDSET	(('i'<<8)|107)	/* Set disk drive spec's.	*/
#define	IOCDDGET	(('i'<<8)|108)	/* Get disk drive spec's.	*/
#define	IOCGSTAT	(('i'<<8)|109)	/* Get disk drive statistics.   */

typedef	struct				/* The structure for IOCFMTST	*/
	{				/* ioctl usage.			*/
	int	fmtst_mn;		/* Magic number = 'FDST'	*/
	int	fmtst_dr;		/* Drive number.		*/
	int	fmtst_sc;		/* Starting cylinder.		*/
	int	fmtst_st;		/* Starting track.		*/
	int	fmtst_ec;		/* Ending cylinder.		*/
	int	fmtst_et;		/* Ending track.		*/
	int	fmtst_p0;		/* Device specific parameter 0. */
	int	fmtst_p1;		/* Device specific parameter 1. */
	int	fmtst_p2;		/* Device specific parameter 2. */
	int	fmtst_p3;		/* Device specific parameter 3. */
	int	fmtst_p4;		/* Device specific parameter 4. */
	int	fmtst_p5;		/* Device specific parameter 5. */
	int	fmtst_p6;		/* Device specific parameter 6. */
	int	fmtst_p7;		/* Device specific parameter 7. */
	int	fmtst_p8;		/* Device specific parameter 8. */
	int	fmtst_p9;		/* Device specific parameter 9. */
	char    fmtst_it[64];		/* Interleave table.		*/
	}	FMTST;

#define	FMTST_MN  'FDST'		/* The magic number.		*/


typedef	struct				/* The IOCFSSET/IOCFSGET	*/
	{				/* control structure.		*/
	int	fspec_mn;		/* Magic number = 'FSSP'.	*/
	int	fspec_sb;		/* Starting block number.	*/
	int	fspec_eb;		/* Ending block number.		*/
	int	fspec_gd;		/* Filesys valid 0/1=bad/good.	*/
	int	fspec_vs;		/* Verify switch 0=off, 1=on.	*/
	int	fspec_dr;		/* Drive number (minor decode). */
	int	fspec_ua;		/* Use alternate sectoring.No=0.*/
	int	fspec_re;		/* Report error msgs. No = 0.	*/
	int	fspec_db;		/* Issue debug messages. No = 0.*/
	int	fspec_rf[7];		/* Reserved for future use.	*/
	}	FSPEC;

#define	FSPEC_MN  'FSSP'		/* The magic number.		*/


typedef	struct				/* The IOCDDSET/IOCDDGET	*/
	{				/* control structure.		*/
	int	dspec_mn;		/* Magic number = 'DDSP'.	*/
	int	dspec_st;		/* Sectors (512 byte) per track.*/
	int	dspec_tc;		/* Tracks (heads) per cylinder.	*/
	int	dspec_cd;		/* Cylinders per drive.		*/
	int	dspec_sc;		/* Sectors per cylinder.	*/
	int	dspec_sr;		/* Step rate.			*/
	int	dspec_rf[10];		/* Reserved for future use.	*/
	}	DSPEC;

#define	DSPEC_MN  'DDSP'		/* The magic number.		*/


#define	GSTAT_ND  8			/* Define the number of drives. */

typedef	struct				/* The IOCGSTAT structure.	*/
	{
	int	  gstat_mn;		/* Magic number = 'STAT'.	*/
	unsigned  gstat_tr[GSTAT_ND];	/* Total number of reads.	*/
	unsigned  gstat_tw[GSTAT_ND];	/* Total number of writes.	*/
	unsigned  gstat_tv[GSTAT_ND];	/* Total number of verifies.	*/
	unsigned  gstat_br[GSTAT_ND];	/* Total number of blocks read.	*/
	unsigned  gstat_bw[GSTAT_ND];	/* Total no. of blocks written.	*/
	unsigned  gstat_bv[GSTAT_ND];	/* Total no. of blocks verified.*/
	unsigned  gstat_sr[GSTAT_ND];	/* Soft read errors per drive.  */
	unsigned  gstat_sw[GSTAT_ND];	/* Soft write errors per drive. */
	unsigned  gstat_sv[GSTAT_ND];	/* Soft verify errors per drive.*/
	unsigned  gstat_hr[GSTAT_ND];	/* Hard read errors per drive.  */
	unsigned  gstat_hw[GSTAT_ND];	/* Hard write errors per drive. */
	unsigned  gstat_hv[GSTAT_ND];	/* Hard verify errors per drive.*/
	int	  gstat_rf[GSTAT_ND-1];	/* Reserved for future use.	*/
	}	  GSTAT;

#define	GSTAT_MN  'STAT'
