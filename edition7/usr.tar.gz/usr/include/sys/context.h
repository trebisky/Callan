/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

/*
 * Context structure.
 * One allocated per active page
 * register context. There are
 * NUMCONTX (16) contexts in hardware.
 */
struct context {
	struct	context *cx_forw;	/* forward pointer */
	struct	context *cx_back;	/* back pointer */
	struct	proc *cx_proc;		/* pointer to proc structure */
	short	cx_daddr;		/* starting data segment address */
	short	cx_dsize;		/* data size of allocated segments */
	short	cx_num;			/* context number of this slot 1 to 1 */
	struct cxphys {
		short	cx_phaddr;	/* sysphys address slot */
		short	cx_phsize;	/* sysphys data slot count */
	} cx_phys[NPHYS];
};

extern struct context context[];
