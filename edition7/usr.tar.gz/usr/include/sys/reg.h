/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

/*
 * Location of the users' stored
 * registers relative to R0.
 * Usage is u.u_ar0[XX].
 */

#define	R0	(0)
#define	R1	(1)
#define	R2	(2)
#define	R3	(3)
#define	R4	(4)
#define	R5	(5)
#define	R6	(6)
#define	R7	(7)
#define AR0	(8)
#define	AR1	(9)
#define	AR2	(10)
#define	AR3	(11)
#define	AR4	(12)
#define	AR5	(13)
#define	AR6	(14)
#define	AR7	(15)
#define	SP	(15)
#define	PC	(18)
#define	RPS	(17)

#define	TBIT	0100000		/* PS trace bit */

/*
 * Label variable (label_t) index locations
 * Usage is u.u_rsav[XX].
 */
#define	LD2	(0)
#define	LD3	(1)
#define	LD4	(2)
#define	LD5	(3)
#define	LD6	(4)
#define	LD7	(5)
#define	LA2	(6)
#define	LA3	(7)
#define	LA4	(8)
#define	LA5	(9)
#define	LA6	(10)
#define	LA7	(11)
#define	LPC	(12)
