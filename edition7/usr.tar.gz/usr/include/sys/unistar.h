/*
 *	COPYRIGHT 1982 BY CALLAN DATA SYSTEMS INCORPORATED.
 *
 *	Use of this code is subject to your disclosure agreement with AT&T,
 *	Western Electric, and Callan Data Systems Corporation.
 *
 */

/*
 * 	Constants and definitions for the UNISTAR CPU board.
 *
 * 	Constants to define the Context Register.
 * 	The UNISTAR has a Context Register which selects
 * 	one sixteenth of the Segment Map. Writing to the
 * 	Context Register sets the current context number.
 */

/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

/*
 * Constants and definitions for the CTS-300 CPU board
 *
 * Constants to define the Context Register.
 * The CTS-300 has a Context Register which selects
 * one sixteenth of the Segment Map. Writing to the
 * Context Register sets the current context number.
 */

#define CONTEXT 0xE00000	/* Context base address */

#define NUMCONTX 16		/* Number of possible contexts */

/*
 * Reading from the Context Register address gets a
 * 16-bit input port which can be used for various
 * things such as system configuration data.
 */

#define	CONFPORT 0xE00000	/* Address of input port */

/* Constants to define the Segment Map Structures */

#define SEGBASE	0xC00000	/* Segment map base address */
#define	NSEGMAP 64		/* Number of segments per context */
#define	SEGINCR	0x8000		/* Increment from one entry to next */
				/* Address of last Segment Map entry */

/*
 * Segment map access control.
 * The Access Controls for each segment are defined
 * in terms of Read, Write, and Execute access, both
 * for the supervisor and for the user. There are
 * 64 such combinations. A segment map entry only has
 * four bits. The 16 potentially most useful
 * combinations of protections were selected. These
 * are defined in the table below.
 */
#define ______	0x000
#define __x___	0x100
#define r_____	0x200
#define r_x___	0x300
#define rw____	0x400
#define rwx___	0x500
#define r__r__	0x600
#define rw_r__	0x700
#define r__rw_	0x800
#define rw_rw_	0x900
#define rw_r_x	0xA00
#define rw_rwx	0xB00
#define r_xr_x	0xC00
#define rwxr_x	0xD00
#define rwx__x	0xE00
#define rwxrwx	0xF00
/* mask for above bits */
#define PROTMASK 0xF00

/* Constants to define the Page Map */

#define PAGEBASE 0xA00000	/* Page map base address */
#define NPAGEMAP 1024		/* Number of Page Map entries */
#define PAGEINCR 0x800		/* Increment from one entry to next */
				/* address of last page map entry */

/*
 * Page Map Acess Control
 * The following constants define the
 * address space in which a particular
 * logical page appears.
 */
#define ASOBRAM	0x0000		/* Map control for on-board-ram */
#define ASONBIO	0x1000		/* Address space is onboard I/O */
#define ASMBRAM	0x2000		/* Address space is MULTIBUS RAM */
#define ASMBIO	0x3000		/* Address space is MULTIBUS I/O */
#define ASINVAL	ASONBIO		/* Indicates an invalid page */


/* Define layout of memory for the CTx-300 */

#define CTLSEG		0x1F8000	/* Control segment */
#define MBIOBASE	0x1FF800 	/* Start of MULTIBUS I/O */
#define NMBUSIOP	1		/* Number of MULTIBUS I/O Pages */
#define NSYSSEG		4		/* Number of on board system segments */
#define NMAPSEG		1		/* Number of mappable system segments */
#define MBUSBUFR	0x1F8000	/* Start of MULTIBUS Buffers */
#define UDOTBASE	0x1FF000	/* Logical base of udot area */
#define SCRPG0		0x1FD000	/* Scratch page 0 */
#define SCRPG1		0x1FD800	/* Scratch page 1 */
#define SCRPG2		0x1FE000	/* Scratch page 2 */
#define SCRPG3		0x1FE800	/* Scratch page 3 */

/*
 * Definitions for memory management.
 */
#define SEGMASK		0x1F8000	/* mask of segment number as address */
#define SEGNMASK	0x3F		/* mask of segment number as number */
#define SEGSHIFT	15		/* shift of segment number */
#define PAGEMASK	0x7800		/* mask of page number */
#define PAGESHIFT	11		/* shift of page number */
#define OFFMASK		0x7FF		/* mask of address offset */
#define ASMASK		0x3000		/* address space mask */
#define PBMASK		0x3FFF		/* page base mask (including address
						space bits) */
	/* context number to actual context data */
#define cxntocx(x)	((x) << 12)

	/* context data to context number */
#define cxtocxn(x)	(((x) >> 12) & 0xF)

	/* virtual address to segment number */
#define vtosegn(x)	(((long)(x) & SEGMASK) >> SEGSHIFT)

	/* virtual address to page number */
/* #define vtopagen(x)	(((long)(x) & SEGMASK) >> SEGSHIFT) */

	/* virtual address to segment register address */
#define vtoseg(x)	((short *)(SEGBASE + ((long)(x) & SEGMASK)))

	/* virtual address to page register address (assumes segments set up) */
#define vtopage(x)	((short *)(PAGEBASE + ((long)(x) & (PAGEMASK|SEGMASK))))

	/* test for multibus memory */
#define ismulti(x)	(((long)(x)&(ASMASK<<PAGESHIFT))==(ASMBRAM<<PAGESHIFT))

/* On board clock */
struct clk {
	short	clk_data;	/* data register */
	short	clk_cmd;	/* command register */
};

#define CLKADDR	((struct clk *)(0x800000))

#define CLK_LMODE	0xFF00	/* Command to load the mode register */
#define CLK_LLOAD	0xFF08	/* Command to load the load register */
#define CLK_LHOLD	0xFF10	/* Command to load the hold register */
#define CLK_MODE	0x0B22	/* F1 + Operating mode D */
#define CLK_100		40000	/* 100 HZ interrupt frequency */
#define CLK_200		20000	/* 200 HZ interrupt frequency */
#define CLK_GO		0xFF20	/* Command to arm counter 2 */
#define CLK_REFR	0xFFE2	/* Command to re-enable clock */
#define CLKTIMER	2	/* Timer 2 */

/*****************************************************************************
 *                                                                           *
 *	THE FOLLOWING ARE THE I/O PORT BASE ADDRESSES AND THE MULTIBUS       *
 *	MEMORY ALLOCATIONS FOR THE I/O PARAMETER BLOCKS AND 512-BYTE         *
 *	BUFFERS FOR THE VARIOUS MULTIBUS CONTROLLERS IN THE SYSTEM.          *
 *                                                                           *
 *****************************************************************************/

/*  The Computer Products Corporation Tapemaster tape controller............ */

#define TMCA_VA		(MBIOBASE + 0x0001)	/* channel attention byte */
#define TMSR_VA		(MBIOBASE + 0x0000)	/* software reset byte */
#define TMSCB_VA	(MBUSBUFR + 0x0000)	/* channel configuration */
#define TMSCP_VA	(MBUSBUFR + 0x0006)	/* channel configuration */
#define TMCCB_VA	(MBUSBUFR + 0x000C)	/* channel control block */
#define TMIOPB_VA	(MBUSBUFR + 0x0014)	/* parameter buffer */
#define TMDBUF_VA	(MBUSBUFR + 0x1000)	/* buffer for on-board mem */

/*
 * NOTE:
 *	TMDBUF_VA points to an area 4k bytes in size.  If you
 *	change the size be sure to change the define of TMDBUFSIZE
 *	in tm.c
 */

/*  The Callan Graphics Controller ......................................... */

#define	CGCCMDP_VA	(MBIOBASE + 0x0070)	/* I/O ports base address.   */


/*  The MSC-9205 Winchester disk controller ................................ */

#define MSCCMDP_VA	(MBIOBASE + 0x0080)	/* I/O ports base address.   */
#define MSCIOPB_VA	(MBUSBUFR + 0x0100)	/* I/O parameter block addr. */
#define MSCDBUF_VA	(MBUSBUFR + 0x0200)	/* Multibus buffer address.  */



/*  The Callan Data Systems Liberty Bay Winchester controller .............. */

#define	CWCCMDP_VA	(MBIOBASE + 0x00a0)	/* I/O ports base address.   */
#define	CWCDBUF_VA      (MBUSBUFR + 0x0600)	/* Multibus buffer address.  */
#define	CWCCPBP_VA      (MBUSBUFR + 0x0800)	/* Command Parameter Block.  */
#define	CWCSTBP_VA	(MBUSBUFR + 0x0900)	/* Status Block.             */



/* The Intel iSBC-220 SMD controller ....................................... */

#define SMD_DIPSW	0x00c0			/* Setting of DIP switches */
#define SMDWAKE_VA	((MBIOBASE + SMD_DIPSW) ^ 1) /* Wakeup address.	     */
#define SMDCBUF_VA	(MBUSBUFR + (SMD_DIPSW << 4)) /* Control blocks.     */
#define SMDDBUF_VA	(MBUSBUFR + 0x0a00)	/* Multibus buffer address.  */


/*  The Callan Data System floppy controller (Intel-208 look-alike) ........ */

#define CFCCMDP_VA	(MBIOBASE + 0x0100)	/* I/O ports base address.   */
#define CFCDBUF_VA	(MBUSBUFR + 0x0400)  	/* Multibus buffer address.  */



/*  The Central Data Corp Quad Serial I/O board............................. */

#define CDCCMDP_VA	(MBIOBASE + 0x01A0)	/* Command ports base */

/*  The INTERRUPT switch interrupt flip/flop reset port .................... */

#define	SWICMDP_VA	(MBIOBASE + 0x07fe)	/* Read/reset interrupt f/f. */
