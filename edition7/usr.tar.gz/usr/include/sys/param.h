/*
 * Copyright 1982 UniSoft Corporation
 *
 * Use of this code is subject to your disclosure agreement with AT&T,
 * Western Electric, and UniSoft Corporation
 */

 /*
 * tunable variables
 */

#define	NBUF	20		/* size of buffer cache */
#define	NINODE	60		/* number of in core inodes */
#define	NFILE	50		/* number of in core file structures */
#define	NMOUNT	12		/* number of mountable file systems */
#define	MAXUPRC	25		/* max processes per user */
#define SSIZE	1		/* initial stack size */
#define SINCR	1		/* stack increment */
#define USTART	0x20000		/* logical start of user program */
#define UEND	0x1D8000	/* logical end of user program +1 */
#define USRBASE	(btoc(USTART))	/* Base of user program */
#define MAXMEM	(usrtop-USRBASE)/* Maximum size of user program */
#define NOFILE	20		/* Max open files per process */
#define	CANBSIZ	256		/* max size of typewriter line */
#define	CMAPSIZ	100		/* size of core allocation area */
#define	SMAPSIZ	100		/* size of swap allocation area */
#define	CXMAPSIZ 20		/* size of swap allocation area */
#define	NCALL	10		/* max simultaneous time callouts */
#define	NPROC	40		/* max number of processes */
#define	NTEXT	10		/* max number of pure texts */
#define	NCLIST	200		/* max total clist size */
#define	HZ	200		/* Ticks/second of the clock */
#define	TIMEZONE (7*60)		/* Minutes westward from Greenwich (MST=7) */
#define	DSTFLAG	0		/* Daylight Saving Time applies here */
#define	MSGBUFS	128		/* Characters saved from error messages */
#define	NCARGS	5120		/* # characters in exec arglist */
#define NPHYS	4		/* number of simultaneous physes */

/*
 * priorities
 * probably should not be
 * altered too much
 */

#define	PSWP	0
#define	PINOD	10
#define	PRIBIO	20
#define	PZERO	25
#define	NZERO	20
#define	PPIPE	26
#define	PWAIT	30
#define	PSLEP	40
#define	PUSER	50

/*
 * signals
 * dont change
 */

#include <signal.h>

/*
 * fundamental constants of the implementation--
 * cannot be changed easily
 */

#define	NBPW	sizeof(int)	/* number of bytes in an integer */
#define	BSIZE	512		/* size of secondary block (bytes) */
/* BSLOP can be 0 unless you have a TIU/Spider */
#define	BSLOP	0		/* In case some device needs bigger buffers */
#define	NINDIR	(BSIZE/sizeof(daddr_t))
#define	BMASK	0777		/* BSIZE-1 */
#define	BSHIFT	9		/* LOG2(BSIZE) */
#define	NMASK	0177		/* NINDIR-1 */
#define	NSHIFT	7		/* LOG2(NINDIR) */
#define	USIZE	1		/* size of user block in core clicks (*2K) */
#define	NULL	0
#define	CMASK	0		/* default mask for file creation */
#define	NODEV	(dev_t)(-1)
#define	ROOTINO	((ino_t)2)	/* i number of all roots */
#define	SUPERB	((daddr_t)1)	/* block number of the super block */
#define	DIRSIZ	14		/* max characters per directory */
#define	NICINOD	100		/* number of superblock inodes */
#define	NICFREE	50		/* number of superblock free blocks */
#define NICALT	50		/* size of bad block list on disk */
#define	INFSIZE	138		/* size of per-proc info for users */
#define	CBSIZE	12		/* number of chars in a clist block */
#define	CROUND	017		/* clist rounding: sizeof(int *) + CBSIZE - 1*/

/*
 * Some macros for units conversion
 */
/* Core clicks (2K bytes) to segments (32K bytes) and vice versa */
#define	ctos(x)	(((long)(x)+15)>>4)
#define stoc(x) ((long)(x)<<4)

/* Bytes to disk blocks */
#define	btod(x)	(((x)+511)>>9)

/* Disk blocks to bytes */
#define	dtob(x)	((x)<<9)

/* Core clicks (2K bytes) to disk blocks */
#define	ctod(x)	((x)<<2)

/* inumber to disk address */
#define	itod(x)	(daddr_t)((((unsigned)(x)+15)>>3))

/* inumber to disk offset */
#define	itoo(x)	(int)(((x)+15)&07)

/* core clicks to bytes */
#define	ctob(x)	((x)<<11)

/* core bytes to clicks */
#define	btoc(x)	((((x)+2047)>>11)&0x1FFFFF)

/* major part of a device */
#define	major(x)	(int)(((x)>>8)&0xFF)

/* minor part of a device */
#define	minor(x)	(int)((x)&0377)

/* make a device number */
#define	makedev(x,y)	(dev_t)((x)<<8 | (y))

typedef	struct { int r[1]; } *	physadr;
typedef	long		daddr_t;
typedef char *		caddr_t;
typedef	long		mem_t;
typedef	unsigned short	ino_t;
typedef	long		time_t;
typedef	long		label_t[13];	/* regs d2-d7, a2-a7, pc */
typedef	short		dev_t;
typedef	long		off_t;

/*
 * Machine-dependent bits and macros
 */
#define	SMODE	0x2000		/* supervisor mode bit,note no user mode bit*/
#define	INTPRI	0x700				/* Priority bits */

#define	CPUPRI(ps)	((ps) & INTPRI)		/* Mask for CPU priority bits */
#define	BASEPRI(ps)	(CPUPRI(ps) != 0)	/* CPU base priority */
#define	USERMODE(ps)	(((ps) & SMODE)==0)	/* User mode definition */

#define void int	/* so berkeley void coersions will work */
#define gsignal signal
#define MIN(a,b)	(((a) < (b))?(a):(b))

/*
 * debug flags
 */
/* #define DSWAP	X	/* swap trace information */

/* #define SPL0()	asm("	movw	#0x2000,sr"); */
/* #define SPL1()	asm("	movw	#0x2100,sr"); */
/* #define SPL2()	asm("	movw	#0x2200,sr"); */
/* #define SPL3()	asm("	movw	#0x2300,sr"); */
/* #define SPL4()	asm("	movw	#0x2400,sr"); */
/* #define SPL5()	asm("	movw	#0x2500,sr"); */
/* #define SPL6()	asm("	movw	#0x2600,sr"); */
/* #define SPL7()	asm("	movw	#0x2700,sr"); */

#define SPL0	spl0
#define SPL1	spl1
#define SPL2	spl2
#define SPL3	spl3
#define SPL4	spl4
#define SPL5	spl5
#define SPL6	spl6
#define SPL7	spl7
