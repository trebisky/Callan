'''\"	TMAC.M @(#)tmacs.src	1.6
.if n .so /usr/lib/macros/mmn
.if t .so /usr/lib/macros/mmt
