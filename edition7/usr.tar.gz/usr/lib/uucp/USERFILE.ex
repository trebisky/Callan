Uucp uses this file to restrict file access on a per user basis.
Each line specifies a path prefix for a list of login_names.
The format is a follows:

[login_name,]...,	/path

There can be up to ten lines of this type.  The file is searched from
the top down and a line without any login_names will be used for all
users not appearing specifically on the of the previous lines.  A tab
character separates the list of users from the path.
