This file tells uucp the name of the system it's running on.
The entire contents of the first line are considered to be the name of
the host system.
