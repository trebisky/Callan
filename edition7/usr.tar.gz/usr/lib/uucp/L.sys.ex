This file lists all the systems uucp knows about.
Each line describes one system.  The format is as follows:

system_name calltime connection_dev baud_rate phone_number \
	[expect Sreply] ...

where
	system_name	is the ascii name of the system.
	calltime	is the time to call that system.  The format of
			this field is described fully in the installation
			instructions.
	connection_dev	is the name of the device (in /dev) to use to
			call this system.
	baud_rate	is the baud_rate this system responds to
	phone_number	is a string representing a phone number for dial-up
			type connections or the device name if there is a
			hard-wired line between the two systems.

	expect		is a string of the form:
		from1[-Freply-from2]...  where
			from1		is a substring to look for in the
					text the system called sent.
			Freply		is what to send back if we don't
					find the substring from1.  Then we
					look for from2, etc.
	Sreply		is what to send back when we find a substring
			from expect.  This process is repeated until the
			list of expect/reply pairs is exausted.

For example, the line:
sys2 Any ttyxx 9600 ttyxx ogin-EOT-ogin uucp ssword secret

describes a hard-wired connection via 'ttyxx' with 'sys2' at 9600 baud.
Any tells uucp to establish the connection whenever there is work to be done.
'ogin-EOT-ogin uucp' tell it to look for the string 'ogin' in what sys2
sends us upon connection and if found to send 'uucp' back.  Otherwise
and EOT or control-D will be sent back and 'ogin' checked for again.
If it is not found the second time uucp will fail.  Otherwise it will
reply with 'uucp' and then expect the string 'ssword' and reply with
'secret' if it finds it or fail if it doesn't.
