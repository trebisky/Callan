This file lists the devices available to connect to other systems.
Each device is either an Autodialer or Hardwired and thus each line
starts with either ACU or DIR respectively.
Each line is formed as follows:
	
	ACU_or_DIR device acu_unit speed

Where
	device		is the device name (in /dev).
	acu-unit	is the device name of the Acu unit (if the first
			field is ACU) or 0 (if the first field is DIR).
	speed		is the baud rate to use over this line.

For example:
	ACU cu10 acu3 300
	ACU cu10 acu12 1200
	DIR tty5 0 9600

Tells uucp that there is a dialout line '/dev/cu10' which is switch
selectable from 300 to 1200 baud depending on whether the acu3 or acu12
path is selected and that tty5 is hardwired at 9600 baud.  The matching
line in L.sys would look like:
	
	sys2 Any tty5 9600 tty5 ogin-EOT-ogin uucp
