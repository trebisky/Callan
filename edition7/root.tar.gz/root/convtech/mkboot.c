/* mkboot - write a bootable disk image for the
 * Convergent Technologies miniframe computer
 * T. Trebisky  8/22/89
 */

/* If you can believe it, the Callan byte swaps every sector it writes
 * to the floppy disk - fine for the Callan, but a mess for us, the following
 * switch invokes byte-swapping logic as we write on that machine.
 */
#define CALLAN

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <a.out.h>

struct ctsup {
	long	magic;		/* word 1-2 of 512 */
	short	fill0[6];	/* words 3-8 */
	short	nheads;		/* word 9 0x3010 --> a0@(0xa) */
	short	sectrk;		/* word 10 0x3012 */
	short	seccyl;		/* word 11 0x3014 */
	char	flags;		/* word 12 0x3016 */
	char	hdseek;
	short	fill1[33];	/* word 13-45 0x3018 never used */
	long	ldrptr;		/* word 46-49 */
	short	ldrcnt;	
	long	hdbptr;		/* word 52-55 */
	short	hdbcnt;
	long	dmpptr;		/* word 58-61 */
	short	dmpcnt;
	short	fill2[456];	/* word 64-511 */
	long	cksum;		/* word 511-512 */
} sblock;

#define KSIZE 1024
char imbuf[KSIZE];

main(argc,argv)
char **argv;
{
	long lsum();
	int sbsize = sizeof ( struct ctsup );
	struct stat sbuf;
	int fd, infd;
	int imsize, imblocks;
	int i;

	--argc;
	++argv;
	if ( argc != 2 )
		error("usage: mkboot aoutfile bootfile");

	if ( (infd = open(argv[0],0)) == -1 )
		error("Cannot open input (a.out) file");
	if ( fstat(infd,&sbuf) == -1 )
		error ("Cannot access input file");

	imsize = sbuf.st_size - sizeof(struct bhdr);
	printf("%d bytes in image\n",imsize);
	imblocks = (imsize+KSIZE-1) / KSIZE;
	
	printf("super block is %d bytes\n",sbsize);
	zfill ( (char *) &sblock, sbsize );

	sblock.magic = 0x55515651;	/* 'UQVQ' */
	sblock.nheads = 2;	/* number of heads (sides) */
	sblock.sectrk = 8;	/* sectors per track */
	sblock.seccyl = 16;	/* sectors per cylinder */
	sblock.flags = 0x1;	/* double density floppy */
	sblock.ldrptr = 1;
	sblock.ldrcnt = imblocks;
	sblock.cksum = (-1) -
			lsum ( (long *) &sblock, (sbsize/sizeof(long))-1 );

	if ( (fd = creat(argv[1],0644)) == -1 )
		error("Cannot open output file");
	bswap ( &sblock, sbsize );
	if ( write ( fd, &sblock, sbsize ) != sbsize )
		error("Write error");
	if ( lseek ( infd, (long) sizeof(struct bhdr), 0 ) == -1 )
		error ("Seek error");
	for ( i=0; i<imblocks-1; i++ ) {
		if ( read(infd,imbuf,KSIZE) != KSIZE )
			error("Read error");
		bswap ( imbuf, KSIZE );
		if ( write(fd,imbuf,KSIZE) != KSIZE )
			error("image write error");
	}
	/* write a complete last block */
	zfill(imbuf,KSIZE);
	if ( read(infd,imbuf,KSIZE) <= 0 )
		error("final read error");
	bswap ( imbuf, KSIZE );
	if ( write(fd,imbuf,KSIZE) != KSIZE )
		error("image write error");
	close(fd);
	exit(0);
}

zfill(buf,nby)
register char *buf;
register nby;
{
	while ( nby-- )
		*buf++ = 0;
}

long lsum (buf, nlong)
register long *buf;
register nlong;
{
	register sum;

	while ( nlong-- )
		sum += *buf++;
	return ( sum );
}

error(s)
char *s;
{
	fprintf(stderr,"%s\n",s);
	exit(1);
}

bswap(buf,n)
register char *buf;
register n;
{
#ifdef CALLAN
	register t;

	for ( ; n ; n -= 2 ) {
		t = *buf;
		*buf = buf[1];
		buf[1] = t;
		buf += 2;
	}
#endif
}
/* END */
