main()
{
	udiv(5,4);
	umod(5,4);
}

udiv(a,b)
unsigned long a, b;
{
	return a / b;
}

umod(a,b)
unsigned long a, b;
{
	return a % b;
}
