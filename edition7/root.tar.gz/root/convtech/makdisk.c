/* mkboot - write a bootable disk image for the
 * Convergent Technologies miniframe computer
 *  This special version writes two test sectors full of bit patterns
 * T. Trebisky  8/29/90
 */

/* If you can believe it, the Callan byte swaps every sector it writes
 * to the floppy disk - fine for the Callan, but a mess for us, the following
 * switch invokes byte-swapping logic as we write on that machine.
 */
#define CALLAN

#include <stdio.h>

#define KSIZE 1024
char imbuf[KSIZE];

char *diskname = "/dev/rf0";

main(argc,argv)
char **argv;
{
	int fd;

	if ( (fd = open(diskname,1)) == -1 )
		error("Cannot open output file");
	makdata(imbuf,KSIZE);
	bswap ( imbuf, KSIZE );
	if ( write(fd,imbuf,KSIZE) != KSIZE )
		error("block write error");
	close(fd);
	exit(0);
}

unsigned char pat[] = { 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
			0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xfb, 0x7f };

makdata(buf,n)
char *buf;
{
	register i;
	register fill;
	
	fill = 0;
	for ( i=0; i<256; ++i )
		buf[i] = fill++;
	fill = 0;
	for ( i=256; i<512; ++i )
		buf[i] = fill++;

	fill = 0;
	for ( i=512; i<1024; ++i ) {
		buf[i] = pat[fill++];
		if ( fill == 16 ) fill = 0;
	}
}

error(s)
char *s;
{
	fprintf(stderr,"%s\n",s);
	exit(1);
}

bswap(buf,n)
register char *buf;
register n;
{
#ifdef CALLAN
	register t;

	for ( ; n ; n -= 2 ) {
		t = *buf;
		*buf = buf[1];
		buf[1] = t;
		buf += 2;
	}
#endif
}
/* END */
