main()
{
	exit(123);
}
